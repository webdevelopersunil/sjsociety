<div class="card card-default">
    <?php if(session('error')): ?>
        <div class="alert alert-danger">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>
    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <div class="card-body text-center">
        <form action="<?php echo e(route('razorpay.payment.store')); ?>" method="POST" >
            <?php echo csrf_field(); ?>
            <script src="https://checkout.razorpay.com/v1/checkout.js"
                    data-key="<?php echo e(env('RAZORPAY_KEY')); ?>"
                    data-amount="10000"
                    data-buttontext="Pay 100 INR"
                    data-name="GeekyAnts official"
                    data-description="Razorpay payment"
                    data-image="/images/logo-icon.png"
                    data-prefill.name="ABC"
                    data-prefill.email="abc@gmail.com"
                    data-theme.color="#ff7529">
            </script>
        </form>
    </div>
</div><?php /**PATH /var/www/html/a_larave/sjsociety/resources/views/payment.blade.php ENDPATH**/ ?>