<link rel="stylesheet" href="https://cdn.datatables.net/1.11.7/css/jquery.dataTables.min.css">
    <style>
        /* Add your custom styles here */
        .data-table {
            width: 100%;
            margin-top: 20px;
            margin-bottom: 20px;
            border-collapse: collapse;
        }

        .data-table th, .data-table td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        @media screen and (max-width: 600px) {
            .data-table {
                overflow-x: auto;
                display: block;
            }
        }
        .view-detail{
            color:red;
        }
        .view-detail:hover{
            color:green;
            border: 2px solid white;
            background: yellow;
        }
    </style>

<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            <?php echo e(__('Dashboard')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-12xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900 dark:text-gray-100">
                    <?php echo e(__("Candidates List!")); ?>


                        <table class="table table-bordered data-table">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>First Name</th>
                                    <th>Last Name</th>
                                    <th>Father/Husband Name</th>
                                    <th>Mother Name</th>
                                    <th>WhatsApp Number</th>
                                    <th>Aadhar Number</th>
                                    <th>Email</th>
                                    <th>Mobile Number</th>
                                    <!-- <th>Second Mobile Number</th> -->
                                    <th>Qualification</th>
                                    <th>Gender</th>
                                    <!-- <th>Nationality</th>
                                    <th>Father Occupation</th>
                                    <th>Village Address</th>
                                    <th>Post Office</th>
                                    <th>District</th>
                                    <th>Pin Code</th>
                                    <th>State</th> -->
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php if($candidates->isEmpty()): ?>
                                <p>No data available</p>
                            <?php else: ?>
                                <?php $__currentLoopData = $candidates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $candidate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($index + 1); ?></td>
                                    <td><?php echo e($candidate->first_name); ?></td>
                                    <td><?php echo e($candidate->last_name); ?></td>
                                    <td><?php echo e($candidate->father_husband_name); ?></td>
                                    <td><?php echo e($candidate->mother_name); ?></td>
                                    <td><?php echo e($candidate->whatsapp_number); ?></td>
                                    <td><?php echo e($candidate->aadhar_number); ?></td>
                                    <td><?php echo e($candidate->email); ?></td>
                                    <td><?php echo e($candidate->mobile_number); ?></td>
                                    <!-- <td><?php echo e($candidate->second_mobile_number); ?></td> -->
                                    <td><?php echo e($candidate->qualification); ?></td>
                                    <td><?php echo e($candidate->gender); ?></td>
                                    <!-- <td><?php echo e($candidate->nationality); ?></td>
                                    <td><?php echo e($candidate->father_occupation); ?></td>
                                    <td><?php echo e($candidate->village_address); ?></td>
                                    <td><?php echo e($candidate->post_office); ?></td>
                                    <td><?php echo e($candidate->district); ?></td>
                                    <td><?php echo e($candidate->pin_code); ?></td>
                                    <td><?php echo e($candidate->state); ?></td> -->
                                    <td><a class="view-detail" class="view-btn" href="<?php echo e(route('candidate.view',$candidate->id)); ?>">View</a></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            </tbody>
                        </table>
                        <?php echo e($candidates->links()); ?>

                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.7/js/jquery.dataTables.min.js"></script>
    <script>
        $(document).ready(function() {
            $('.data-table').DataTable();
        });
    </script>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /var/www/html/a_larave/sjsociety/resources/views/dashboard.blade.php ENDPATH**/ ?>