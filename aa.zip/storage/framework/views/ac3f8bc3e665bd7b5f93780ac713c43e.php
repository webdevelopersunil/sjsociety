<link rel="stylesheet" href="https://cdn.datatables.net/1.11.7/css/jquery.dataTables.min.css">
<link rel="stylesheet" href="<?php echo e(asset('css/candidate_detail.css')); ?>">

<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            <?php echo e(__('Candidate Detail')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-6xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900 dark:text-gray-100">
                    
                    <div class="flex items-center justify-end mt-4">
                        <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.primary-button','data' => ['class' => 'ml-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('primary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'ml-4']); ?>
                            <a href="<?php echo e(route('dashboard')); ?>">
                                <?php echo e(__('Go Back')); ?>

                            </a>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                    </div>
                    
                    <!-- <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
                            First Name : <span><?php echo e(ucfirst($candidate->first_name)); ?></span>
                    </h2> -->

                    <div class="invoice-box">
                        <table cellpadding="0" cellspacing="0">
                            <tr class="top">
                                <td colspan="2">
                                    <table>
                                        <tr>
                                            <td class="font-semibold" style="text-align:right;"  >
                                                Invoice ID#: <span style="color:red" >3645456124</span><br />
                                                Created At: <span style="color:red" >January 1, 2023</span><br />
                                            </td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>

                            <tr class="information">
                                <td colspan="2">
                                    <table>
                                        <tr>
                                            <td>
                                                <?php echo e(isset($candidate->village_address) && !empty($candidate->village_address) ? ucfirst($candidate->village_address) : '<span style="color: red;">----</span>'); ?><br />
                                                <?php echo e($candidate->post_office); ?><br />
                                                <!-- <?php echo e($candidate->district); ?>, <?php echo e($candidate->state); ?> <?php echo e($candidate->pin_code); ?> -->
                                                <?php echo e(isset($candidate->district) && !empty($candidate->district) ? ucfirst($candidate->district) : '<span style="color: red;">----</span>'); ?>, 
                                                <?php echo e(isset($candidate->state) && !empty($candidate->state) ? ucfirst($candidate->state) : '<span style="color: red;">----</span>'); ?>

                                                <?php echo e(isset($candidate->pin_code) && !empty($candidate->pin_code) ? ucfirst($candidate->pin_code) : '<span style="color: red;">----</span>'); ?>

                                            </td>

                                            <td>
                                            <?php echo e(isset($candidate->first_name) && !empty($candidate->first_name) ? ucfirst($candidate->first_name) : '<span style="color: red;">----</span>'); ?>

                                            <?php echo e(isset($candidate->last_name) && !empty($candidate->last_name) ? ucfirst($candidate->last_name) : '<span style="color: red;">----</span>'); ?><br />
                                                <!-- John Doe<br /> -->
                                            <span style="color:red;" ><?php echo e(ucfirst($candidate->email)); ?></span><br />
                                            Mob No.: <?php echo e(isset($candidate->mobile_number) && !empty($candidate->mobile_number) ? ucfirst($candidate->mobile_number) : '<span style="color: red;">----</span>'); ?><br />
                                            </td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>

                            <tr class="heading">
                                <td>Candidate Detail</td>

                                <td>Check #</td>
                            </tr>

                            <tr class="details">
                                <td>Father/Husband Name</td>
                                <td>
                                <?php echo e(isset($candidate->father_husband_name) && !empty($candidate->father_husband_name) ? ucfirst($candidate->father_husband_name) : '<span style="color: red;">----</span>'); ?>

                                </td>
                            </tr>
                            <tr class="details">
                                <td>Mother Name</td>
                                <td>
                                <?php echo e(isset($candidate->mother_name) && !empty($candidate->mother_name) ? ucfirst($candidate->mother_name) : '<span style="color: red;">----</span>'); ?>

                                </td>
                            </tr>
                            <tr class="details">
                                <td>Whatsapp Number</td>
                                <td>
                                <?php echo e(isset($candidate->whatsapp_number) && !empty($candidate->whatsapp_number) ? ucfirst($candidate->whatsapp_number) : '<span style="color: red;">----</span>'); ?>

                                </td>
                            </tr>
                            <tr class="details">
                                <td>Aadhar Number</td>
                                <td>
                                <?php echo e(isset($candidate->aadhar_number) && !empty($candidate->aadhar_number) ? ucfirst($candidate->aadhar_number) : '<span style="color: red;">----</span>'); ?>

                                </td>
                            </tr>
                            <tr class="details">
                                <td>Second Mobile Number</td>
                                <td>
                                <?php echo e(isset($candidate->second_mobile_number) && !empty($candidate->second_mobile_number) ? ucfirst($candidate->second_mobile_number) : '<span style="color: red;">----</span>'); ?>

                                </td>
                            </tr>
                            
                            <tr class="details">
                                <td>Qualification</td>
                                <td>
                                <?php echo e(isset($candidate->qualification) && !empty($candidate->qualification) ? ucfirst($candidate->qualification) : '<span style="color: red;">----</span>'); ?>

                                </td>
                            </tr>
                            <tr class="details">
                                <td>Gender</td>
                                <td>
                                <?php echo e(isset($candidate->gender) && !empty($candidate->gender) ? ucfirst($candidate->second_mobile_number) : '<span style="color: red;">----</span>'); ?>

                                </td>
                            </tr>
                            <tr class="details">
                                <td>Nationality</td>
                                <td style="color: black;" >
                                <?php echo e(isset($candidate->nationality) && !empty($candidate->nationality) ? ucfirst($candidate->nationality) : '<span style="color: red;">----</span>'); ?>

                                </td>
                            </tr>
                            <tr class="details">
                                <td>father_occupation</td>
                                <td>
                                <?php echo e(isset($candidate->father_occupation) && !empty($candidate->father_occupation) ? ucfirst($candidate->father_occupation) : '<span style="color: red;">----</span>'); ?>

                                </td>
                            </tr>
                            <tr class="details">
                                <td>Post Office</td>
                                <td>
                                <?php echo e(isset($candidate->post_office) && !empty($candidate->post_office) ? ucfirst($candidate->post_office) : '<span style="color: red;">----</span>'); ?>

                                </td>
                            </tr>

                            <tr class="heading">
                                <td>Item</td>

                                <td>Price</td>
                            </tr>

                            <tr class="item">
                                <td>Website design</td>

                                <td>$300.00</td>
                            </tr>

                            <tr class="item">
                                <td>Hosting (3 months)</td>

                                <td>$75.00</td>
                            </tr>

                            <tr class="item last">
                                <td>Domain name (1 year)</td>

                                <td>$10.00</td>
                            </tr>

                            <tr class="total">
                                <td></td>

                                <td>Total: $385.00</td>
                            </tr>
                        </table>
                    </div>
                    

                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /var/www/html/a_larave/boilerplate-breeze-blade/resources/views/candidate_view.blade.php ENDPATH**/ ?>